function loadAssignmentsView(){
    isUserAuthenticatedViews(templateFiles.adminAssignmentsPage);
}


function loadAdminAddAssignmentForm(){
    isUserAuthenticatedViews(templateFiles.adminAddAssignmentForm);
}
