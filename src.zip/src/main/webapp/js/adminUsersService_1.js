function loadUsersView(){
    isUserAuthenticatedViews(templateFiles.adminUsersPage);
}

function loadAdminAddUserForm(){
    isUserAuthenticatedViews(templateFiles.adminAddUserForm);
}

function loadAdminAddStudentForm(){
    isUserAuthenticatedViews(templateFiles.adminAddStudentForm);
}

function loadAdminAddLecturerForm(){
    isUserAuthenticatedViews(templateFiles.adminAddLecturerForm);
}