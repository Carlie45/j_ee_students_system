/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j_ee_project.j_ee_students_system.settings.startup;

import javax.ejb.Singleton;

/**
 *
 * @author Lightning
 */
@Singleton
public class SystemInitializer {

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    
    
}
